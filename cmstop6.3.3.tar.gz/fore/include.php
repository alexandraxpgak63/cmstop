<?php
require_once CORE_ROOT.'include/common.inc.php';
require_once CORE_ROOT.'include/fore.inc.php';
?>