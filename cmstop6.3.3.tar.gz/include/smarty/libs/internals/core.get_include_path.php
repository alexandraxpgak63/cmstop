<?php
function smarty_core_get_include_path(&$params, &$smarty) {
	return false;
}?>
