<?php
if(!defined('CORE_ROOT')) exit;

function cloudkeywords($content, $num = 10) {
	return false;
}

function cuturl($url) {
	return false;
}